<?php

namespace App\Services\Task;

use App\Models\Task;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;


class TaskFetchingService{
  public function AllMine()
  {
    $tasks = Task::query() 
    -> where('broker_id', Auth::user() -> broker -> id) 
    -> orderBy('updated_at', 'DESC')
    -> get();
   
    // add file urls to each of the tasks
    foreach ($tasks as $task){
        $task -> Files;
        if($task -> writer_id){
          $task -> writer -> user;
        }

        if($task -> status === 1){

          foreach ($task -> offers as $offer) {
            // $offer -> messages -> first();
            $offer -> writer -> user;

            $offer -> last_message = $offer -> messages() -> orderBy('created_at', 'DESC') -> take(1) -> get();
            if($offer  -> messages -> where('read_at', null)  -> where('user_id', '!=', 1) -> where('user_id', '!=', Auth::user() -> id) -> first()){
              $offer -> unread_message = true;
            }
          }
          
          foreach ($task -> bids as $bid) {
            $bid -> writer -> user;
            $bid -> last_message = $bid -> messages() -> orderBy('created_at', 'DESC') -> take(1) -> get();
            if($bid  -> messages -> where('read_at', null)  -> where('user_id', '!=', 1) -> where('user_id', '!=', Auth::user() -> id) -> first()){
              $bid -> unread_message = true;
            }
          }
        }

    }

    return $tasks;
  }

  public function getAllDoneByMe(){
    // get all the tasks the writer has ever taken
    $tasks = Auth::user() -> writer -> tasks;

    // add file urls to each of the tasks
    foreach ($tasks as $task){
        $task -> files;
        $task -> broker -> user; 
        $task -> Files;
        // = DB::table('taskfiles') -> where('task_id', $task -> id) -> get();
    }

    return ['tasks' => $tasks];

    // can get other details on the individual tasks here as the need arises

  }

  public function getTaskForBidding(Request $request){
    $task = Task::where('code', $request -> task_code) -> first();
    $task -> files;
    $task -> broker -> user; 
    $task -> Files;

    if($task -> status > 1 || !$task){
      return 404;
    }

    return $task;
  }
}