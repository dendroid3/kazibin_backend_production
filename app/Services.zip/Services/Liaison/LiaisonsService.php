<?php

namespace App\Services\Liaison;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

use App\Services\SystemLog\LogCreationService;
use Illuminate\Support\Facades\DB;

use App\Models\Liaisonrequest;
// use App\Models\Requestmessage;
// use App\Models\User;
use App\Models\Writer;
use App\Models\Broker;
use Illuminate\Support\Facades\Log;

class LiaisonsService {
  public function sendRequestToWriter(Request $request, LogCreationService $log_service){
    // ensure request does not already exist
    // if(DB::table('liaisonrequests') -> where([
    //       ['broker_id', '=', Auth::user() -> id],
    //       ['writer_id', '=', $request -> writer_id]
    //   ]) -> exists()){
    //     return null;
    //   }

    $liaison_request = new Liaisonrequest;
    $liaison_request -> id =  Str::orderedUuid() -> toString();
    $liaison_request -> initiator_id = Auth::user() -> id;
    // $liaison_request -> cost_per_page = $request -> cost_per_page;
    // $liaison_request -> pay_day = $request -> pay_day;
    $liaison_request -> broker_id = Auth::user() -> broker -> id;
    $liaison_request -> writer_id = $request -> writer_id;
    $liaison_request -> save();

    $log_service -> createLogOnRequestToWriter($liaison_request, Auth::user());

    return $liaison_request;
  }

  public function sendRequestToBroker(Request $request, LogCreationService $log_service){
     // ensure request does not already exist
    //  if(DB::table('liaisonrequests') -> where([
    //     ['writer_id', '=', Auth::user() -> id],
    //     ['broker_id', '=', $request -> broker_id]
    // ]) -> exists()){
    //   return null;
    // }

    $liaison_request = new Liaisonrequest;
    $liaison_request -> id =  Str::orderedUuid() -> toString();
    $liaison_request -> initiator_id = Auth::user() -> id;
    // $liaison_request -> cost_per_page = $request -> cost_per_page;
    // $liaison_request -> pay_day = $request -> pay_day;
    $liaison_request -> writer_id = Auth::user() -> writer -> id;
    $liaison_request -> broker_id = $request -> broker_id;
    $liaison_request -> save();

    $log_service -> createLogOnRequestToBroker($liaison_request, Auth::user());

    return $liaison_request;
  }

  public function getLiaisonRequests(){

    $writers_requests = Liaisonrequest::query()
    // DB::table('liaisonrequests') 
                        -> where('broker_id', Auth::user() -> broker -> id)
                        -> orderBy('created_at', 'DESC')
                        -> get();
    if($writers_requests){

      foreach ($writers_requests as $writer_request) {
        $last_message = DB::table('requestmessages') -> where([
          ['broker_id', '=', $writer_request -> broker_id],
          ['writer_id', '=', $writer_request -> writer_id]
        ]) -> select('sender_id', 'message', 'created_at') -> orderBy('created_at', 'DESC') -> take(1) -> get()[0]; 
        $writer_request -> last_message = $last_message;
        $writer_request -> writer = Writer::find($writer_request -> writer_id) -> user;
        // DB::table('users') -> where('id', $writer_request -> writer_id) -> select('username', 'code') -> get()[0];
        $writer_request -> mine = Auth::user() -> id == $writer_request -> initiator_id;
        
        if($writer_request  -> messages -> where('read_at', null)  -> where('sender_id', '!=', 1) -> where('sender_id', '!=', Auth::user() -> id) -> first()){
          $writer_request -> unread_message = true;
        }

      }

    }

    $brokers_requests = Liaisonrequest::query()
    // DB::table('liaisonrequests') 
                        -> where('writer_id', Auth::user() -> writer -> id)
                        -> orderBy('created_at', 'DESC')
                        -> get();

    if($brokers_requests){
      foreach ($brokers_requests as $broker_request) {
        $last_message = DB::table('requestmessages') -> where([
          ['broker_id', '=', $broker_request -> broker_id],
          ['writer_id', '=', $broker_request -> writer_id]
        ]) -> select('sender_id', 'message', 'created_at') -> orderBy('created_at', 'DESC') -> take(1) -> get()[0];
        $broker_request -> last_message = $last_message;
        $broker_request -> broker = Broker::find($broker_request -> broker_id) -> user;
        // DB::table('users') -> where('id', $broker_request -> broker_id) -> select('username', 'code') -> get();
        $broker_request -> mine = Auth::user() -> id == $broker_request -> initiator_id;
        
        if($broker_request  -> messages -> where('read_at', null)  -> where('sender_id', '!=', 1) -> where('sender_id', '!=', Auth::user() -> id) -> first()){
          $broker_request -> unread_message = true;
        }
    }
    

    }

    return [
      'writers_requests' => ($writers_requests) ? $writers_requests : null, 
      'brokers_requests' => ($brokers_requests) ? $brokers_requests : null
    ];
  }

  public function rejectRequestFromBroker($request, $log_service){

    $this -> changeRequestStatus($request -> broker_id, Auth::user() -> writer -> id, 3);
    $broker = Broker::find($request -> broker_id) -> user;
    
    $my_message = $log_service -> createSystemMessage(Auth::user() -> id,
    'You rejected request from broker, '. $broker -> username . ' code: ' . $broker -> code,
     $request -> broker_id,
     'Request Rejected'
    );
    
    $writer = Auth::user();

    $message_to_broker = $log_service -> createSystemMessage($request -> broker_id, 
    'Your request to writer, ' . $writer -> username .' code: ' . Auth::user() -> code . ' has been rejected.', 
    Auth::user() -> id,
    'Request Rejected');

    return  $my_message -> message;

  }

  public function rejectRequestFromWriter($request, $log_service){
    $this -> changeRequestStatus(Auth::user() -> broker -> id, $request -> writer_id, 3);

    $writer = Writer::find($request -> writer_id) -> user;
    
    $my_message = $log_service -> createSystemMessage(
    Auth::user() -> id, 
    'You rejected request from writer, ' . $writer -> username . ' code ' . $writer -> code, 
    $request -> writer_id,
    'Request Rejected');

    $broker = Auth::user(); 

    $system_message = $log_service -> createSystemMessage(
    $request -> writer_id, 
    'Your request to broker, '. $broker -> username. ' code ' . Auth::user() -> code . ' has been rejected', 
    Auth::user() -> id,
    'Request Rejected');

    return  $my_message -> message;

  }

  public function attachBrokerToMe($request, $log_service){
    $user = Auth::user();
    // return $user;
    $check = DB::table('broker_writer') -> where([
      ['broker_id', '=', $request -> broker_id],
      ['writer_id', '=', $user -> writer -> id],
    ]) -> exists();
    if(!$check){
      
      DB::table('broker_writer')->insert([
        'broker_id' => $request -> broker_id, 
        'writer_id' => $user -> writer -> id,
        'cost_per_page' => 300
      ]);

      // Auth::user() -> writer -> brokers() -> attach($request -> broker_id);
      $this -> changeRequestStatus($request -> broker_id, $user -> writer -> id, 4); //broker_id , writer_id
      
      $broker = Broker::find($request -> broker_id) -> user;
      
      $log_service -> createSystemMessage(
        $user -> id, 
        'You accepted request from broker, code ' . $broker -> code . " " . $broker -> username . " has been added to your network", 
        $request -> broker_id,
        'Request Accepted'
      );
      
      $log_service -> createSystemMessage(
        $request -> broker_id, 
        'Your request to writer code' . $user -> code . ' has been accepted. ' . $user -> username . ' has been added to your network', 
        $user -> id,
        'Request Accepted'
      );

      return true;
    }
    
    return false;
  }

  public function attachWriterToMe($request, $log_service){
    $broker = Auth::User();
    $check = false;
    // DB::table('broker_writer') -> where([
    //   ['broker_id', '=', $broker -> id],
    //   ['writer_id', '=', $request -> writer_id],
    // ]) -> exists();

    if(!$check){
      $writer = Writer::find($request -> writer_id) -> user;
      $broker -> broker -> writers() -> attach($request -> writer_id, ['cost_per_page' => 350]);

      // DB::table('broker_writer')->insert([
      //   'broker_id' => $broker -> id, 
      //   'writer_id' => $writer -> id
      // ]);
      // return $broker;

    $this -> changeRequestStatus($broker -> broker -> id, $request -> writer_id, 4);//broker_id , writer_id
    $log_service -> createSystemMessage(
      $broker -> id, 
      'You accepted request from writer, code: ' . $writer -> code ." " . $writer -> username . " has been added to your network", 
      $writer -> id,
      'Request Accepted'
    );
    $log_service -> createSystemMessage(
      $writer ->id, 
      'Your request to broker, code: ' . $broker -> code . ' has been accepted.' . $broker -> name . " has been added to your network",
      $broker ->id,
      'Request Accepted'
    );

    return $broker;  

    } 

    return false;

  }
  
  public function changeRequestStatus($broker_id, $writer_id, $status){
    DB::table('liaisonrequests') -> where([
      ['broker_id', '=', $broker_id],
      ['writer_id', '=', $writer_id]
    ]) -> update([
      'status' => $status
    ]);
  }

}