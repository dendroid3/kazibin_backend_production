<?php

namespace App\Services\Offer;

use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use App\Services\SystemLog\LogCreationService;
use Illuminate\Support\Facades\DB;

use App\Models\Taskoffer;
use App\Models\Task;
use App\Models\Broker;
use App\Models\Taskoffermessage;
use App\Models\User;
use App\Models\Taskmessage;
use Illuminate\Http\Request;

class OfferService
{
  public function create($task, LogCreationService $log_service, $taker)
  {
    $offer = new Taskoffer();
    $offer -> id = Str::orderedUuid() -> toString();
    #$task -> id;
    $offer -> task_id = $task -> id;
    $offer -> writer_id = $taker;
    $offer -> save();

    $log_service -> createOfferLog($offer, $task);

    return ['validated' => true, 'created' => true];
  }

  public function rejectOffer(Request $request, LogCreationService $log_service)
  {
    $offer = Taskoffer::find($request -> offer_id);
    $offer -> status = 3;
    $offer -> updated_at = Carbon::now();
    $offer -> push();

    $task = Task::find($request -> task_id);
    $task -> updated_at = Carbon::now();
    $task -> push();

    $writer_message = "You rejected " . $task -> broker -> user -> username . "'s offer on task " .
                      $task -> code . ": " . $task ->topic;

    $log_service -> createSystemMessage(
      Auth::user() -> id, 
      $writer_message,
      $task -> broker -> user -> id,
      'Offer Rejected'
    ); 

    $broker_message = $offer -> writer -> user -> username . " rejected your offer on task " . $task -> code .  ": " . $task -> topic;

    $log_service -> createSystemMessage(
      $task -> broker -> user -> id,
      $broker_message,
      Auth::user() -> id, 
      'Offer Rejected'
    );

    return $writer_message;
  }

  public function acceptOffer(Request $request, LogCreationService $log_service){
    $offer = Taskoffer::find($request -> offer_id);

    $task = Task::find($request -> task_id);
    $task -> writer_id = Auth::user() -> Writer -> id;
    $task -> updated_at = Carbon::now();
    $task -> status = 2;
    $task -> push();

    $task -> broker -> User;
    $task -> files;

    $brokers_message ='Offer on job code ' . $task -> code . ' has been accepted by writer code: ' . Auth::user() -> code;

    $log_service -> createSystemMessage($task -> Broker -> User -> id, $brokers_message, $task -> id, 'Offer Accepted');

    $writers_message = 'You accepted offer on task code ' . $task -> code;

    $log_service -> createSystemMessage(Auth::user() -> id, $writers_message, $task -> id, 'Offer Accepted');

    foreach ($task -> Offers as $offer) {
      if($offer -> writer_id == $task -> writer_id){
        $this -> migrateOfferMessagesToJobMessages($offer, $task -> id);
        $offer -> status = 4;
      } else {
        $offer -> status = 5;
      }
      $offer -> push();
    }

    foreach (explode('_', $task -> takers)  as $taker) {
        if(Auth::user() -> id != $taker){
          $sorry_message = 'Offer on task code: ' . $task -> code . ' pulled after task was accepted by another writer';

          $log_service -> createSystemMessage($taker ? $taker : 99999, $sorry_message, $task -> id, 'Offer Pulled');
        }
    }

    return $writers_message;
  }

  public function cancelOffer(Request $request, LogCreationService $log_service)
  {
    
    $offer = Taskoffer::find($request -> offer_id);
    $offer -> status = 2;
    $offer -> updated_at = Carbon::now();
    $offer -> push();

    $task = Task::find($request -> task_id);
    $task -> updated_at = Carbon::now();
    $task -> push();

    $writer_message = $task -> broker -> user -> username . " canceled your offer on task " . $task -> code .  ": " . $task -> topic;


    $log_service -> createSystemMessage(
      Auth::user() -> id, 
      $writer_message,
      $task -> broker -> user -> id,
      'Offer Canceled'
    ); 

    $broker_message = "You canceled " . $offer -> writer -> user -> username . "'s offer on task " .
                      $task -> code . ": " . $task ->topic;

    $log_service -> createSystemMessage(
      $task -> broker -> user -> id,
      $broker_message,
      Auth::user() -> id, 
      'Offer Canceled'
    );

    return $broker_message;
  }

  public function getMine(){
    $task_offers = Taskoffer::query() 
                -> where('writer_id', Auth::user() -> writer -> id) 
                -> orderBy('created_at', 'desc') 
                -> select('created_at', 'task_id', 'id', 'status')
                -> get();

    if($task_offers){
      foreach ($task_offers as $task_offer) {
            $task_offer -> task -> broker -> user;
            $task_offer -> messages -> first();
            
            if($task_offer  -> messages -> where('read_at', null)  -> where('user_id', '!=', 1) -> where('user_id', '!=', Auth::user() -> id) -> first()){
              $task_offer -> unread_message = true;
            }
        }
        //  orderBy('updated_at', 'desc')
        return $task_offers;
            // 'job_id' => $task_offer -> job_id,

    } else {
        return[
            'offers' => null
        ];
    }
  }

  public function getOfferMessages(Request $request){
    // $messages = Taskoffer::
    
    $messages = Taskoffermessage::query()
    // DB::table('taskoffermessages')
                  -> where('taskoffer_id', $request -> task_offer_id) 
                  -> orderBy('created_at', 'ASC')
                  -> get();
    // find($request -> task_offer_id) -> messages;
    foreach ($messages as $message) {
      
        if((!$message -> read_at) && ($message -> user_id != Auth::user() -> id)){
          $message -> read_at = Carbon::now();
          $message -> push();
        }
        $message -> mine = $message -> user_id === Auth::user() -> id;
    }

    return $messages;
  }

  public function sendOfferMessages(Request $request){
    $task_offer_message = new Taskoffermessage();
    $task_offer_message -> id = Str::orderedUuid() -> toString();
    $task_offer_message -> user_id = Auth::user() -> id;
    $task_offer_message -> taskoffer_id = $request -> task_offer_id;
    $task_offer_message -> message = $request -> message;
    $task_offer_message -> save();

    return $task_offer_message;
  }
  
  public function migrateOfferMessagesToJobMessages($offer, $task_id){

    $text_messages = DB::table('taskoffermessages')->where('taskoffer_id', $offer -> id)-> select(
      'message', 'user_id', 'created_at', 'type', 'delivered_at', 'read_at'
    ) ->get();

    foreach ($text_messages as $message) {
        $task_message = new Taskmessage;
        $task_message -> id = Str::orderedUuid() -> toString();
        $task_message -> user_id = $message -> user_id;
        $task_message -> task_id = $task_id;
        $task_message -> message = $message -> message;
        $task_message -> type = $message -> type;
        $task_message -> created_at = $message -> created_at;
        $task_message -> delivered_at = $message -> delivered_at;
        $task_message -> read_at = $message -> read_at;
        $task_message -> save();
    }

    $task_message = new Taskmessage;
    $task_message -> id = Str::orderedUuid() -> toString();
    $task_message -> user_id = 1;
    $task_message -> task_id = $task_id;
    $task_message -> message = '--- Job has been assigned from offer ---';
    $task_message -> save();
  }
}
