<?php

namespace App\Services\Profile;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;

use App\Models\User;
use App\Models\Task;
use Illuminate\Support\Facades\DB;

class ProfileService {
    public function getDashboardDetails(Request $request){
        $posted_all = Task::where('broker_id', Auth::user() -> broker -> id) -> count();

        
        $credited_invoices_count = Auth::user() -> broker -> Invoices -> count();
        $debited_invoices_count = Auth::user() -> writer -> Invoices -> count();

        $invoices_count = $credited_invoices_count + $debited_invoices_count;
        
        $posted_unassigned = Task::where([
            ['broker_id', Auth::user() -> broker -> id],
            ['status', 1]
        ]) -> count();
        

        $posted_underway = Task::where([
            ['broker_id', Auth::user() -> broker -> id],
            ['status', 2]
        ]) -> count();
        
        $posted_completed = Task::where([
            ['broker_id', Auth::user() -> broker -> id],
            ['status', 3]
        ]) -> count();
        
        $posted_canceled = Task::where([
            ['broker_id', Auth::user() -> broker -> id],
            ['status', 4]
        ]) -> count();
        
        $posted_paid = Task::where([
            ['broker_id', Auth::user() -> broker -> id],
            ['status', 6]
        ]) -> count();

        
        $taken_all = Task::where('writer_id', Auth::user() -> writer -> id) -> count();
        
        $taken_underway = Task::where([
            ['writer_id', Auth::user() -> writer -> id],
            ['status', 2]
        ]) -> count();
        
        $taken_completed = Task::where([
            ['writer_id', Auth::user() -> writer -> id],
            ['status', 3]
        ]) -> count();
        
        $taken_canceled = Task::where([
            ['writer_id', Auth::user() -> writer -> id],
            ['status', 4]
        ]) -> count();

        $taken_invoiced = Task::where([
            ['writer_id', Auth::user() -> writer -> id],
            ['status', 5]
        ]) -> count();
        
        $taken_paid = Task::where([
            ['writer_id', Auth::user() -> writer -> id],
            ['status', 6]
        ]) -> count();

        $offers_all = Auth::user() -> writer -> offers -> count();
        $offers_accepted = Auth::user() -> writer -> offers -> where('status', 4) -> count();
        $offers_rejected = Auth::user() -> writer -> offers -> where('status', 3) -> count();
        $offers_cancelled = Auth::user() -> writer -> offers -> where('status', 2) -> count();
        $offers_pending = Auth::user() -> writer -> offers -> where('status', 1) -> count();
        
        $bids_all = Auth::user() -> writer -> bids -> count();
        $bids_accepted = Auth::user() -> writer -> bids -> where('status', 4) -> count();
        $bids_rejected = Auth::user() -> writer -> bids -> where('status', 3) -> count();
        $bids_pulled = Auth::user() -> writer -> bids -> where('status', 2) -> count();
        $bids_pending = Auth::user() -> writer -> bids -> where('status', 1) -> count();

        return [
            'posted' => [
                'posted_all' => $posted_all,
                'posted_unassigned' => $posted_unassigned,
                'posted_underway' => $posted_underway,
                'posted_completed' => $posted_completed,
                'posted_canceled' => $posted_canceled,
                'posted_paid' => $posted_paid
            ],
            
            'taken' => [
                'taken_all' => $taken_all,
                'taken_underway' => $taken_underway,
                'taken_completed' => $taken_completed,
                'taken_canceled' => $taken_canceled,
                'taken_paid' => $taken_paid,
                'taken_invoiced' => $taken_invoiced
            ],
            
            'offers' => [
                'offers_all' => $offers_all,
                'offers_accepted' => $offers_accepted,
                'offers_rejected' => $offers_rejected,
                'offers_cancelled' => $offers_cancelled,
                'offers_pending' => $offers_pending,
            ],
            
            'bids' => [
                'bids_all' => $bids_all,
                'bids_accepted' => $bids_accepted,
                'bids_rejected' => $bids_rejected,
                'bids_pulled' => $bids_pulled,
                'bids_pending' => $bids_pending,
                'bids_is_green' => false
            ],

            'invoices' =>[
                'invoices_count' => $invoices_count,
                'credited_invoices_count' => $credited_invoices_count,
                'debited_invoices_count' => $debited_invoices_count,
            ]

            // 'bids'
        ];
    }

    public function getBrokerMetrics(Request $request){
        $user = User::find($request -> user_id);

        $broker = $user -> broker;
        $writers_count = count($broker -> writers); # -> count;
        $total_tasks =  count($broker -> tasks);
        $available_tasks = $broker -> tasks -> where('status', 1);
        $cancelled_tasks =  count($broker -> tasks -> where('status', 4));
        $paid_tasks =  count($broker -> tasks -> where('status', 6));
        $invoices_count = count($broker-> Invoices);

        return [
            'writers_count' => $writers_count,
            'total_tasks' => $total_tasks,
            'available_tasks' => $available_tasks,
            'cancelled_tasks' => $cancelled_tasks,
            'paid_tasks' => $paid_tasks,
            'invoices_count' => $invoices_count,
            'broker' => $user
        ];
    }

    public function getWriterMetrics(Request $request){
        $user = User::find($request -> user_id);

        $writer = $user -> writer;
        $brokers_count = count($writer -> brokers); # -> count;
        $total_tasks =  count($writer -> tasks);
        $available_tasks = count($writer -> tasks -> where('status', 2));
        $cancelled_tasks =  count($writer -> tasks -> where('status', 4));
        $paid_tasks =  count($writer -> tasks -> where('status', 6));
        $invoices_count = count($writer-> Invoices);

        return [
            'brokers_count' => $brokers_count,
            'total_tasks' => $total_tasks,
            'available_tasks' => $available_tasks,
            'cancelled_tasks' => $cancelled_tasks,
            'paid_tasks' => $paid_tasks,
            'invoices_count' => $invoices_count,
        ];
    }
}