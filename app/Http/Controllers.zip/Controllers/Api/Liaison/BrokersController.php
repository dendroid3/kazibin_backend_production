<?php

namespace App\Http\Controllers\Api\Liaison;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\Liaison\BrokersService;

class BrokersController extends Controller
{
    public function getAll(Request $request, BrokersService $brokers_service){
        
        return response() -> json([
            'brokers' => $brokers_service -> getAll()
        ]);
        
    }

    public function getMyBrokers(BrokersService $brokers_service){
        
        return response() -> json([
            'brokers' => $brokers_service -> getMyBrokers(),
            'status' => 200
        ]);
        
    }
}
