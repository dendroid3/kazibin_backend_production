<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use App\Services\Auth\RegistrationService;
class RegisterController extends Controller
{
    
    public function create(Request $request, RegistrationService $register_request){

        $response = $register_request -> create($request);
        
        if(!$response['validated']){
            return response() -> json(['errors' => $response['errors']], 201);
        }

        return response() -> json($response);
    
    }

    public function createProfile(Request $request, RegistrationService $register_request){

        return response() -> json([
            'user' => $register_request -> createProfile($request),
            'success' => 'profile created'
        ]);

    }

    public function verifyEmailAccount(Request $request){
        //check verification code exists
        $user = DB::table('users') -> where([
            ['email_verification', '=', $request->email_verification],
            ['email', '=', $request->email]
        ]) -> first();
        if(!$user){
            $user_verified = DB::table('users') -> where([
                ['email_verification', '=', null],
                ['email', '=', $request->email]
            ]) -> first();

            //If verification code does is null and email exists, then the email has already been verified
            if($user_verified){
                return response() -> json([
                    'error' => 'email already verified'
                ], 202);
            }

            //If the email does not exist, or exists; but the verification code is not null but is not the same as sent in the request, then the verification fails.
            return response() -> json([
                'error' => 'verification failed'
            ], 201);
        }

        /*
            If both the email and verification code match a record in the database, then the verification code in the record is put to null to signify that it has been verified,
            take home point is that verified accounts have a null record in the 'email_verification' field.
        */
        $user = DB::table('users') -> where([
            ['email_verification', '=', $request->email_verification],
            ['email', '=', $request->email]
        ]) -> update([
            'email_verification' => null
        ]);

        return response() -> json([
            'success' => 'verification succeeded'
        ]);
    }
}
